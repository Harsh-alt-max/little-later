// Little Later Chrome Extension — Clipper, Saved Links, Collab Folders & Serialized Two-Way Firestore Sync
const STORE_USER = 'll_user_v3';
const STORE_FOLDERS = 'll_folders_v1';
const STORE_ITEMS = 'll_items_v1';
const STORE_DELETED = 'll_deleted_ids_v1';
const FIREBASE_PROJECT_ID = 'littlelater-61969';
const FIREBASE_API_KEY = 'AIzaSyB892SNxeXdCML_APdGchJzF6k6hAVtbsE';

let currentUser = JSON.parse(localStorage.getItem(STORE_USER) || 'null');
let folders = JSON.parse(localStorage.getItem(STORE_FOLDERS) || 'null') || [
  { name: 'Work', kind: 'work', icon: 'work' },
  { name: 'Love', kind: 'love', icon: 'heart' },
  { name: 'Hobby', kind: 'hobby', icon: 'spark' }
];
let items = JSON.parse(localStorage.getItem(STORE_ITEMS) || '[]');
let deletedIds = new Set(JSON.parse(localStorage.getItem(STORE_DELETED) || '[]'));

const syncChannel = (typeof BroadcastChannel !== 'undefined') ? new BroadcastChannel('ll_collab_sync') : null;

let activeMode = 'clip';
let selectedFolder = folders[0]?.name || 'Work';
let savedFilterFolder = 'all';
let activeDetailFolder = '';
let syncInFlight = null;

function escapeHtml(val = '') {
  return String(val).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

function showToast(msg) {
  const el = document.getElementById('statusToast');
  if (!el) return;
  el.textContent = msg;
  el.classList.add('visible');
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => el.classList.remove('visible'), 2500);
}

function isLinkOrCollabNote(item) {
  if (!item) return false;
  if (item.kind === 'todoList' || item.kind === 'todo' || item.kind === 'reminder') return false;
  return Boolean(item.url) || item.kind === 'note' || item.kind === 'link';
}

function getFolderIconId(f) {
  if (!f) return '#i-folder';
  if (f.kind === 'work' || f.icon === 'work') return '#i-work';
  if (f.kind === 'love' || f.icon === 'heart') return '#i-heart';
  if (f.kind === 'hobby' || f.icon === 'spark') return '#i-spark';
  return '#i-folder';
}

function getFolderCollabId(folder) {
  if (folder?.collabId && String(folder.collabId).startsWith('cf_')) return folder.collabId;
  const owner = String(folder?.ownerEmail || currentUser?.email || 'user')
    .trim().toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
  const cleanName = String(folder?.name || 'shared')
    .trim().toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
  const cleanId = `cf_${owner}_${cleanName || 'default'}`;
  if (folder) folder.collabId = cleanId;
  return cleanId;
}

function saveLocalCache() {
  localStorage.setItem(STORE_FOLDERS, JSON.stringify(folders));
  localStorage.setItem(STORE_ITEMS, JSON.stringify(items));
  localStorage.setItem(STORE_DELETED, JSON.stringify(Array.from(deletedIds).slice(-500)));
  if (currentUser) localStorage.setItem(STORE_USER, JSON.stringify(currentUser));
  else localStorage.removeItem(STORE_USER);
}

function persistLocal(fromRemote = false) {
  saveLocalCache();
  if (!fromRemote) {
    try {
      syncChannel?.postMessage({ version: Date.now(), folders, items });
    } catch (e) {}
    if (currentUser?.email) {
      syncUserAndCollabWithFirestore(currentUser.email, currentUser.name, true);
    }
  }
}

async function checkPendingGoogleSession() {
  const sessId = localStorage.getItem('ll_pending_google_session');
  if (!sessId) return false;
  const baseDocs = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/databases/(default)/documents`;
  try {
    const r = await fetch(`${baseDocs}/collab_state/auth_${encodeURIComponent(sessId)}?key=${FIREBASE_API_KEY}`, { cache: 'no-store' });
    if (!r.ok) return false;
    const doc = await r.json();
    const email = (doc?.fields?.email?.stringValue || '').trim().toLowerCase();
    const name = (doc?.fields?.name?.stringValue || '').trim();
    if (email && email.includes('@')) {
      localStorage.removeItem('ll_pending_google_session');
      await syncUserAndCollabWithFirestore(email, name || email.split('@')[0], false);
      document.getElementById('authView')?.classList.add('hidden');
      document.getElementById('mainView')?.classList.remove('hidden');
      showToast(`Signed in as ${email}`);
      return true;
    }
  } catch (e) {}
  return false;
}

async function syncUserAndCollabWithFirestore(email, fallbackName = '', allowPush = false) {
  if (syncInFlight) {
    try { await syncInFlight; } catch (e) {}
  }
  const run = (async () => {
    const cleanEmail = String(email || '').trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@')) return false;

    const baseDocs = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/databases/(default)/documents`;
    let resolvedName = fallbackName || currentUser?.name || cleanEmail.split('@')[0];

    // 1. Pull & Merge /users/{email} first so we NEVER overwrite phone items when saving from extension
    try {
      const userRes = await fetch(`${baseDocs}/users/${encodeURIComponent(cleanEmail)}?key=${FIREBASE_API_KEY}`, { cache: 'no-store' });
      if (userRes.ok) {
        const doc = await userRes.json();
        const storedName = doc?.fields?.name?.stringValue || '';
        if (storedName) resolvedName = storedName;
        const rawBackup = doc?.fields?.backupPayload?.stringValue || '';
        if (rawBackup) {
          const parsed = JSON.parse(rawBackup);
          const remoteDeleted = Array.isArray(parsed.deletedIds) ? parsed.deletedIds : [];
          remoteDeleted.forEach(id => deletedIds.add(String(id)));

          if (Array.isArray(parsed.folders)) {
            parsed.folders.forEach(rf => {
              if (!rf?.name) return;
              const idx = folders.findIndex(f => f.name.toLowerCase() === rf.name.toLowerCase());
              if (idx >= 0) folders[idx] = { ...folders[idx], ...rf };
              else folders.push(rf);
            });
          }

          items = items.filter(x => !deletedIds.has(String(x.id)));

          if (Array.isArray(parsed.items)) {
            parsed.items.forEach(ri => {
              if (!ri?.id || deletedIds.has(String(ri.id))) return;
              if (ri.thumbnail === 'mascot.png') ri.thumbnail = '';
              const matchF = folders.find(f => f.name.toLowerCase() === String(ri.folder || '').toLowerCase());
              if (matchF) ri.folder = matchF.name;
              const idx = items.findIndex(x => String(x.id) === String(ri.id));
              if (idx >= 0) {
                const localTime = items[idx].updatedAt || items[idx].savedAt || 0;
                const remoteTime = ri.updatedAt || ri.savedAt || 0;
                if (remoteTime > localTime) items[idx] = ri;
              } else {
                items.push(ri);
              }
            });
          }
        }
      }
    } catch (e) {}

    // 2. Pull /user_invites/{email} so shared collab folders from phone appear automatically
    try {
      const invRes = await fetch(`${baseDocs}/user_invites/${encodeURIComponent(cleanEmail)}?key=${FIREBASE_API_KEY}`, { cache: 'no-store' });
      if (invRes.ok) {
        const invDoc = await invRes.json();
        const invList = JSON.parse(invDoc?.fields?.invitesPayload?.stringValue || '[]');
        if (Array.isArray(invList)) {
          invList.forEach(inv => {
            if (!inv?.collabId || !inv?.name) return;
            let localF = folders.find(f => f.collabId === inv.collabId || f.name.toLowerCase() === inv.name.toLowerCase());
            if (!localF) {
              folders.push({
                name: inv.name,
                kind: 'folder',
                icon: inv.icon || 'folder',
                collab: true,
                collabId: inv.collabId,
                ownerEmail: inv.ownerEmail || '',
                ownerName: inv.ownerName || '',
                collaborators: []
              });
            } else {
              localF.collab = true;
              localF.collabId = inv.collabId;
              if (inv.ownerEmail) localF.ownerEmail = inv.ownerEmail;
              if (inv.ownerName) localF.ownerName = inv.ownerName;
            }
          });
        }
      }
    } catch (e) {}

    // 3. Pull & Merge each collaborative folder /collab_folders/{cid}
    for (const f of folders.filter(x => x.collab)) {
      const cid = getFolderCollabId(f);
      try {
        const cfRes = await fetch(`${baseDocs}/collab_folders/${encodeURIComponent(cid)}?key=${FIREBASE_API_KEY}`, { cache: 'no-store' });
        if (cfRes.ok) {
          const cfDoc = await cfRes.json();
          const rawPayload = cfDoc?.fields?.payload?.stringValue || '';
          if (rawPayload) {
            const parsed = JSON.parse(rawPayload);
            if (parsed.folder) {
              f.ownerEmail = parsed.folder.ownerEmail || f.ownerEmail || '';
              f.ownerName = parsed.folder.ownerName || f.ownerName || '';
              f.collaborators = Array.isArray(parsed.folder.collaborators) ? parsed.folder.collaborators : (f.collaborators || []);
            }
            const cfDeleted = new Set([
              ...(Array.isArray(f.deletedIds) ? f.deletedIds : []),
              ...(Array.isArray(parsed.deletedIds) ? parsed.deletedIds : [])
            ]);
            f.deletedIds = Array.from(cfDeleted);
            items = items.filter(x => !(x.folder?.toLowerCase() === f.name.toLowerCase() && cfDeleted.has(String(x.id))));
            if (Array.isArray(parsed.items)) {
              parsed.items.forEach(ri => {
                if (!ri?.id || cfDeleted.has(String(ri.id))) return;
                if (ri.thumbnail === 'mascot.png') ri.thumbnail = '';
                ri.folder = f.name;
                const idx = items.findIndex(x => String(x.id) === String(ri.id));
                if (idx >= 0) {
                  const localTime = items[idx].updatedAt || items[idx].savedAt || 0;
                  const remoteTime = ri.updatedAt || ri.savedAt || 0;
                  if (remoteTime > localTime) items[idx] = ri;
                } else {
                  items.push(ri);
                }
              });
            }
          }
        }
      } catch (e) {}
    }

    currentUser = {
      name: resolvedName,
      email: cleanEmail,
      signedInAt: currentUser?.signedInAt || Date.now()
    };

    // 4. If allowPush is true, push the merged state back to /users/{email} and /collab_folders/{cid}
    if (allowPush) {
      try {
        const cleanFolders = folders.map(f => ({ ...f, image: '' }));
        const cleanItems = items
          .filter(x => !deletedIds.has(String(x.id)))
          .map(x => ({
            ...x,
            thumbnail: (x.thumbnail && (x.thumbnail.startsWith('data:') || x.thumbnail === 'mascot.png')) ? '' : (x.thumbnail || '')
          }));
        const backupPayload = JSON.stringify({
          folders: cleanFolders,
          items: cleanItems,
          deletedIds: Array.from(deletedIds).slice(-300),
          updatedAt: Date.now()
        });
        const mask = 'updateMask.fieldPaths=name&updateMask.fieldPaths=email&updateMask.fieldPaths=backupPayload&updateMask.fieldPaths=lastSeenAt';
        await fetch(`${baseDocs}/users/${encodeURIComponent(cleanEmail)}?key=${FIREBASE_API_KEY}&${mask}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fields: {
              name: { stringValue: String(currentUser.name || cleanEmail.split('@')[0]) },
              email: { stringValue: cleanEmail },
              backupPayload: { stringValue: backupPayload },
              lastSeenAt: { integerValue: String(Date.now()) }
            }
          })
        });
      } catch (e) {}

      for (const f of folders.filter(x => x.collab)) {
        const cid = getFolderCollabId(f);
        const cfDeleted = new Set(Array.isArray(f.deletedIds) ? f.deletedIds : []);
        const folderItems = items
          .filter(x => (x.folder || '').toLowerCase() === f.name.toLowerCase() && !cfDeleted.has(String(x.id)))
          .map(x => ({
            ...x,
            folder: f.name,
            thumbnail: (x.thumbnail && (x.thumbnail.startsWith('data:') || x.thumbnail === 'mascot.png')) ? '' : (x.thumbnail || '')
          }));
        const fPayload = JSON.stringify({
          folder: {
            name: f.name,
            kind: 'folder',
            icon: f.icon || 'folder',
            collab: true,
            collabId: cid,
            ownerEmail: f.ownerEmail || cleanEmail,
            ownerName: f.ownerName || currentUser.name || cleanEmail.split('@')[0],
            collaborators: Array.isArray(f.collaborators) ? f.collaborators : []
          },
          items: folderItems,
          deletedIds: Array.from(cfDeleted),
          updatedAt: Date.now()
        });
        try {
          await fetch(`${baseDocs}/collab_folders/${encodeURIComponent(cid)}?key=${FIREBASE_API_KEY}&updateMask.fieldPaths=payload&updateMask.fieldPaths=version`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              fields: {
                version: { integerValue: String(Date.now()) },
                payload: { stringValue: fPayload }
              }
            })
          });
        } catch (e) {}
      }
    }

    saveLocalCache();
    renderAll();
    return true;
  })();

  syncInFlight = run;
  return run;
}

function renderHeader() {
  const dot = document.getElementById('userDot');
  const label = document.getElementById('userLabel');
  const signedInBox = document.getElementById('signedInBox');
  const signedInEmailText = document.getElementById('signedInEmailText');
  if (currentUser && currentUser.email) {
    dot?.classList.remove('guest');
    if (label) label.textContent = currentUser.name || currentUser.email.split('@')[0];
    signedInBox?.classList.remove('hidden');
    if (signedInEmailText) signedInEmailText.textContent = `Signed in as ${currentUser.email}`;
  } else {
    dot?.classList.add('guest');
    if (label) label.textContent = 'Sign in';
    signedInBox?.classList.add('hidden');
    if (signedInEmailText) signedInEmailText.textContent = '';
  }

  const validLinks = items.filter(x => Boolean(x.url) && isLinkOrCollabNote(x) && !deletedIds.has(String(x.id)));
  const savedCnt = document.getElementById('savedTabCount');
  const foldersCnt = document.getElementById('foldersTabCount');
  if (savedCnt) savedCnt.textContent = String(validLinks.length);
  if (foldersCnt) foldersCnt.textContent = String(folders.length);
}

function switchMode(mode) {
  activeMode = mode;
  document.querySelectorAll('#modeTabs .mode-tab').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.mode === mode);
  });
  document.getElementById('paneClip')?.classList.toggle('hidden', mode !== 'clip');
  document.getElementById('paneSaved')?.classList.toggle('hidden', mode !== 'saved');
  document.getElementById('paneFolders')?.classList.toggle('hidden', mode !== 'folders');
  renderAll();
}

function renderClipperFolders() {
  const host = document.getElementById('folderChips');
  const pill = document.getElementById('selectedFolderPill');
  if (!host) return;
  if (!folders.some(f => f.name.toLowerCase() === selectedFolder.toLowerCase())) {
    selectedFolder = folders[0]?.name || 'Work';
  } else {
    const matched = folders.find(f => f.name.toLowerCase() === selectedFolder.toLowerCase());
    if (matched) selectedFolder = matched.name;
  }
  const selObj = folders.find(f => f.name === selectedFolder);
  if (pill) {
    pill.textContent = selObj?.collab ? `${selectedFolder} · Collab` : selectedFolder;
  }
  host.innerHTML = folders.map(f => {
    const isSel = f.name === selectedFolder;
    const iconId = getFolderIconId(f);
    return `
      <button class="folder-chip ${isSel ? 'selected' : ''}" data-folder="${escapeHtml(f.name)}" type="button">
        <svg><use href="${iconId}"/></svg>
        <span>${escapeHtml(f.name)}</span>
        ${f.collab ? '<span class="collab-dot" title="Collab folder"></span>' : ''}
      </button>`;
  }).join('');
}

function renderLinkCardHtml(item, inCollab = false) {
  const thumbSrc = (item.thumbnail && item.thumbnail !== 'mascot.png') ? item.thumbnail : 'mascot.png';
  const folderObj = folders.find(f => f.name.toLowerCase() === String(item.folder || '').toLowerCase());
  const folderBadge = item.folder
    ? `${escapeHtml(item.folder)}${folderObj?.collab ? ' · Collab' : ''}`
    : 'Saved';
  const sourceLabel = item.source || (item.url ? 'Saved link' : 'Note');
  const titleText = item.title || item.url || 'Saved idea';
  const noteHtml = item.note ? `<p class="ext-idea-note">${escapeHtml(item.note)}</p>` : '';

  if (item.kind === 'note' && !item.url) {
    return `
      <article class="ext-idea-card" data-item-id="${escapeHtml(item.id)}">
        <div class="ext-idea-copy">
          <div class="ext-idea-source">${escapeHtml(item.senderName || 'You')} · Note</div>
          <h3 class="ext-idea-title">${escapeHtml(item.title || item.note || '')}</h3>
        </div>
        <div class="ext-idea-foot">
          <span class="rect-pill">${folderBadge}</span>
          <button class="ext-action-link danger" data-remove-id="${escapeHtml(item.id)}" type="button">Remove</button>
        </div>
      </article>`;
  }

  return `
    <article class="ext-idea-card" data-item-id="${escapeHtml(item.id)}">
      <div class="ext-idea-top">
        <div class="ext-idea-thumb">
          <img src="${escapeHtml(thumbSrc)}" alt="" onerror="this.src='mascot.png'">
        </div>
        <div class="ext-idea-copy">
          <div class="ext-idea-source">${escapeHtml(sourceLabel)}${item.folder ? ` · ${escapeHtml(item.folder)}` : ''}</div>
          <h3 class="ext-idea-title">${escapeHtml(titleText)}</h3>
          ${noteHtml}
        </div>
      </div>
      <div class="ext-idea-foot">
        <span class="rect-pill">${folderBadge}</span>
        <div>
          ${item.url ? `<button class="ext-action-link" data-open-url="${escapeHtml(item.url)}" type="button">Open</button>` : ''}
          <button class="ext-action-link ${inCollab ? 'danger' : ''}" data-remove-id="${escapeHtml(item.id)}" type="button">${inCollab ? 'Remove' : 'Done'}</button>
        </div>
      </div>
    </article>`;
}

function renderSavedView() {
  const filterHost = document.getElementById('savedFolderFilters');
  const listHost = document.getElementById('savedLinksList');
  if (!filterHost || !listHost) return;

  if (savedFilterFolder !== 'all' && !folders.some(f => f.name.toLowerCase() === savedFilterFolder.toLowerCase())) {
    savedFilterFolder = 'all';
  }

  filterHost.innerHTML = [
    `<button class="folder-chip ${savedFilterFolder === 'all' ? 'selected' : ''}" data-saved-filter="all" type="button">All</button>`,
    ...folders.map(f => `
      <button class="folder-chip ${savedFilterFolder.toLowerCase() === f.name.toLowerCase() ? 'selected' : ''}" data-saved-filter="${escapeHtml(f.name)}" type="button">
        <span>${escapeHtml(f.name)}</span>
        ${f.collab ? '<span class="collab-dot"></span>' : ''}
      </button>`)
  ].join('');

  const q = (document.getElementById('savedSearchInput')?.value || '').trim().toLowerCase();
  let shown = items
    .filter(x => Boolean(x.url) && isLinkOrCollabNote(x) && !deletedIds.has(String(x.id)))
    .sort((a, b) => (b.savedAt || 0) - (a.savedAt || 0));

  if (savedFilterFolder !== 'all') {
    shown = shown.filter(x => (x.folder || '').toLowerCase() === savedFilterFolder.toLowerCase());
  }
  if (q) {
    shown = shown.filter(x =>
      [x.title, x.note, x.url, x.source, x.folder].some(v => String(v || '').toLowerCase().includes(q))
    );
  }

  if (!shown.length) {
    listHost.innerHTML = `
      <div class="empty-box">
        <img src="mascot.png" alt="">
        <h3>No saved links here yet.</h3>
        <p>Save any page from the Save link tab or sign in to sync your phone saves.</p>
      </div>`;
    return;
  }

  listHost.innerHTML = shown.map(item => {
    const fObj = folders.find(f => f.name.toLowerCase() === String(item.folder || '').toLowerCase());
    return renderLinkCardHtml(item, Boolean(fObj?.collab));
  }).join('');
}

function renderFoldersView() {
  const gridWrap = document.getElementById('foldersGridWrap');
  const detailWrap = document.getElementById('folderDetailWrap');
  const gridHost = document.getElementById('extFolderGrid');
  if (!gridWrap || !detailWrap || !gridHost) return;

  if (activeDetailFolder && folders.some(f => f.name.toLowerCase() === activeDetailFolder.toLowerCase())) {
    gridWrap.classList.add('hidden');
    detailWrap.classList.remove('hidden');
    renderFolderDetailSubview();
    return;
  }

  activeDetailFolder = '';
  gridWrap.classList.remove('hidden');
  detailWrap.classList.add('hidden');

  gridHost.innerHTML = folders.map((f, idx) => {
    const count = items.filter(x => (x.folder || '').toLowerCase() === f.name.toLowerCase() && isLinkOrCollabNote(x) && !deletedIds.has(String(x.id))).length;
    const iconId = getFolderIconId(f);
    return `
      <button class="ext-folder-tile theme-${idx % 6}" data-open-folder="${escapeHtml(f.name)}" type="button">
        <div class="ext-folder-top">
          <svg><use href="${iconId}"/></svg>
          ${f.collab ? '<span class="collab-tag">Collab</span>' : ''}
        </div>
        <div>
          <span class="ext-folder-name">${escapeHtml(f.name)}</span>
          <span class="ext-folder-count">${count} ${count === 1 ? 'saved link' : 'saved links'}</span>
        </div>
      </button>`;
  }).join('');
}

function renderFolderDetailSubview() {
  const folder = folders.find(f => f.name.toLowerCase() === activeDetailFolder.toLowerCase());
  if (!folder) return;

  const titleEl = document.getElementById('extFolderTitle');
  const badgeEl = document.getElementById('extFolderBadge');
  const collabBar = document.getElementById('extCollabBar');
  const toggleCollabBtn = document.getElementById('toggleCollabBtn');
  const itemsHost = document.getElementById('extFolderItems');

  const folderItems = items
    .filter(x => (x.folder || '').toLowerCase() === folder.name.toLowerCase() && isLinkOrCollabNote(x) && !deletedIds.has(String(x.id)))
    .sort((a, b) => (b.savedAt || 0) - (a.savedAt || 0));

  if (titleEl) titleEl.textContent = folder.name;
  if (badgeEl) {
    badgeEl.textContent = folder.collab
      ? `Collab · ${folderItems.length}`
      : `${folderItems.length} saved`;
  }
  if (toggleCollabBtn) {
    toggleCollabBtn.textContent = folder.collab ? 'Collab ON' : 'Make Collab';
  }

  if (collabBar) {
    if (folder.collab) {
      const members = Array.isArray(folder.collaborators) ? folder.collaborators : [];
      const ownerName = folder.ownerName || currentUser?.name || 'You';
      collabBar.classList.remove('hidden');
      collabBar.innerHTML = `
        <span><strong>${escapeHtml(ownerName)}</strong>${members.length ? ` + ${members.length} in collab` : ' · Shared space'}</span>
        <span>Shared folder</span>`;
    } else {
      collabBar.classList.add('hidden');
      collabBar.innerHTML = '';
    }
  }

  if (!itemsHost) return;
  if (!folderItems.length) {
    itemsHost.innerHTML = `
      <div class="empty-box">
        <img src="mascot.png" alt="">
        <h3>Nothing in ${escapeHtml(folder.name)} yet.</h3>
        <p>${folder.collab ? 'Paste a link or write a message below to share with your collaborators.' : 'Save links here or paste a link below.'}</p>
      </div>`;
    return;
  }

  itemsHost.innerHTML = folderItems.map(item => {
    const sender = item.senderName || currentUser?.name || 'You';
    const timeStr = item.savedAt
      ? new Intl.DateTimeFormat(undefined, { hour: 'numeric', minute: '2-digit' }).format(new Date(item.savedAt))
      : '';
    return `
      <div>
        ${folder.collab ? `<div class="collab-sender-line">${escapeHtml(sender)}${timeStr ? ` · ${escapeHtml(timeStr)}` : ''} ✓✓</div>` : ''}
        ${renderLinkCardHtml(item, Boolean(folder.collab))}
      </div>`;
  }).join('');
}

async function handleSaveClippedIdea() {
  const btn = document.getElementById('saveIdeaBtn');
  const btnText = document.getElementById('saveBtnText');
  const titleVal = (document.getElementById('tabTitleInput')?.value || '').trim() || 'Saved link';
  const rawUrlVal = (document.getElementById('tabUrlText')?.textContent || '').trim();
  const urlVal = (rawUrlVal && rawUrlVal.startsWith('http')) ? rawUrlVal : 'https://www.youtube.com/watch?v=dQw4w9WgXcQ';
  const srcVal = (document.getElementById('tabSourcePill')?.textContent || '').trim() || 'Web link';
  const thumbImg = document.querySelector('#tabThumb img')?.getAttribute('src') || '';
  const noteVal = (document.getElementById('noteInput')?.value || '').trim();
  const folderObj = folders.find(f => f.name.toLowerCase() === selectedFolder.toLowerCase()) || folders[0];
  const nowTs = Date.now();

  const newItem = {
    id: String(nowTs),
    kind: 'link',
    sender: 'me',
    senderName: currentUser?.name || 'You',
    url: urlVal,
    source: srcVal,
    title: titleVal,
    thumbnail: (thumbImg && thumbImg !== 'mascot.png') ? thumbImg : '',
    note: noteVal,
    folder: folderObj?.name || 'Work',
    folderKind: folderObj?.kind || 'folder',
    savedAt: nowTs,
    updatedAt: nowTs,
    reminder: 0,
    optedOutBy: []
  };

  items.unshift(newItem);
  if (btn) btn.disabled = true;
  if (btnText) btnText.textContent = `Saved to ${newItem.folder} ✓`;
  showToast(`Saved to ${newItem.folder}`);
  persistLocal();
  renderAll();

  setTimeout(() => {
    if (btn) btn.disabled = false;
    if (btnText) btnText.textContent = 'Save it for later';
    const noteEl = document.getElementById('noteInput');
    if (noteEl) noteEl.value = '';
  }, 1300);
}

function handleCreateOrJoinFolder() {
  const input = document.getElementById('newFolderInput');
  const raw = (input?.value || '').trim();
  if (!raw) {
    input?.focus();
    return;
  }

  if (raw.includes('join=')) {
    const qIndex = raw.indexOf('?');
    const params = new URLSearchParams(qIndex >= 0 ? raw.slice(qIndex + 1) : raw);
    const joinName = params.get('join') || params.get('folder');
    const joinCid = params.get('cid') || '';
    const joinBy = params.get('by') || 'Collaborator';
    const joinOwner = params.get('owner') || '';
    if (joinName) {
      let f = folders.find(x => x.name.toLowerCase() === joinName.toLowerCase());
      if (!f) {
        f = {
          name: joinName,
          kind: 'folder',
          icon: 'folder',
          collab: true,
          collabId: joinCid,
          ownerName: joinBy,
          ownerEmail: joinOwner,
          collaborators: []
        };
        folders.push(f);
      } else {
        f.collab = true;
        if (joinCid) f.collabId = joinCid;
      }
      if (input) input.value = '';
      selectedFolder = f.name;
      activeDetailFolder = f.name;
      persistLocal();
      renderAll();
      showToast(`Joined "${f.name}" collab folder`);
      return;
    }
  }

  if (folders.some(f => f.name.toLowerCase() === raw.toLowerCase())) {
    showToast('Folder already exists.');
    return;
  }

  const newF = { name: raw, kind: 'folder', icon: 'folder', collab: false };
  folders.push(newF);
  selectedFolder = newF.name;
  if (input) input.value = '';
  persistLocal();
  renderAll();
  showToast(`Created "${newF.name}"`);
}

function handleSendInFolder() {
  const input = document.getElementById('folderQuickInput');
  const raw = (input?.value || '').trim();
  if (!raw || !activeDetailFolder) {
    input?.focus();
    return;
  }

  const isUrl = raw.includes('://') || raw.startsWith('www.');
  const cleanUrl = isUrl ? (raw.includes('://') ? raw : `https://${raw}`) : '';
  const nowTs = Date.now();
  const fObj = folders.find(f => f.name.toLowerCase() === activeDetailFolder.toLowerCase());

  const newItem = {
    id: String(nowTs),
    kind: isUrl ? 'link' : 'note',
    sender: 'me',
    senderName: currentUser?.name || 'You',
    url: cleanUrl,
    source: isUrl ? (typeof detectPlatform === 'function' ? detectPlatform(cleanUrl) : 'Shared link') : 'Collab note',
    title: raw,
    thumbnail: '',
    note: '',
    folder: fObj ? fObj.name : activeDetailFolder,
    folderKind: fObj?.kind || 'folder',
    savedAt: nowTs,
    updatedAt: nowTs,
    reminder: 0,
    optedOutBy: []
  };

  items.unshift(newItem);
  if (input) input.value = '';
  persistLocal();
  renderAll();
  showToast(isUrl ? `Link added to ${newItem.folder}` : `Sent to ${newItem.folder}`);
}

function renderAll() {
  renderHeader();
  renderClipperFolders();
  if (activeMode === 'saved') renderSavedView();
  if (activeMode === 'folders') renderFoldersView();
}

async function handleGoogleAuthClick() {
  const btn = document.getElementById('googleBridgeBtn');
  const txt = document.getElementById('googleBridgeBtnText');
  if (txt) txt.textContent = 'Connecting to Google…';
  if (btn) btn.disabled = true;

  try {
    const completedPending = await checkPendingGoogleSession();
    if (completedPending) return;

    const chromeAcc = (typeof window.getChromeGoogleAccount === 'function')
      ? await window.getChromeGoogleAccount()
      : null;

    if (chromeAcc && chromeAcc.email) {
      await syncUserAndCollabWithFirestore(chromeAcc.email, chromeAcc.email.split('@')[0], false);
      document.getElementById('authView')?.classList.add('hidden');
      document.getElementById('mainView')?.classList.remove('hidden');
      showToast(`Signed in as ${currentUser.email}`);
      return;
    }

    const sessionId = `ext_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    localStorage.setItem('ll_pending_google_session', sessionId);
    const bridgeBase = ['https://harsh-alt-max.github.io', 'little-later', 'google-auth.html'].join('/');
    if (typeof window.openSavedUrl === 'function') {
      window.openSavedUrl(`${bridgeBase}?session=${encodeURIComponent(sessionId)}&from=extension`);
    }
    showToast('Complete Google sign-in in the opened tab, then reopen Little Later.');
  } finally {
    if (txt) txt.textContent = 'Continue with Google';
    if (btn) btn.disabled = false;
  }
}

async function handleEmailSyncLogin() {
  const email = (document.getElementById('authEmail')?.value || '').trim().toLowerCase();
  const passOrName = (document.getElementById('authPass')?.value || '').trim();
  if (!email || !email.includes('@')) {
    showToast('Enter your @gmail.com address first.');
    document.getElementById('authEmail')?.focus();
    return;
  }
  const btn = document.getElementById('authLoginBtn');
  if (btn) {
    btn.disabled = true;
    btn.textContent = 'Syncing…';
  }
  try {
    await syncUserAndCollabWithFirestore(email, passOrName || email.split('@')[0], false);
    document.getElementById('authView')?.classList.add('hidden');
    document.getElementById('mainView')?.classList.remove('hidden');
    showToast(`Signed in as ${currentUser.email}`);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = 'Sign in';
    }
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  renderAll();
  await checkPendingGoogleSession();
  if (currentUser?.email) {
    syncUserAndCollabWithFirestore(currentUser.email, currentUser.name, false);
  }

  document.getElementById('modeTabs')?.addEventListener('click', e => {
    const tab = e.target.closest('[data-mode]');
    if (!tab) return;
    if (tab.dataset.mode === 'folders') activeDetailFolder = '';
    switchMode(tab.dataset.mode);
    if (currentUser?.email) syncUserAndCollabWithFirestore(currentUser.email, currentUser.name, false);
  });

  document.getElementById('folderChips')?.addEventListener('click', e => {
    const chip = e.target.closest('[data-folder]');
    if (!chip) return;
    selectedFolder = chip.dataset.folder;
    renderClipperFolders();
  });

  document.getElementById('quickNewFolderBtn')?.addEventListener('click', () => {
    activeDetailFolder = '';
    switchMode('folders');
    setTimeout(() => document.getElementById('newFolderInput')?.focus(), 60);
  });

  document.getElementById('saveIdeaBtn')?.addEventListener('click', handleSaveClippedIdea);

  document.getElementById('savedSearchInput')?.addEventListener('input', renderSavedView);
  document.getElementById('savedFolderFilters')?.addEventListener('click', e => {
    const btn = e.target.closest('[data-saved-filter]');
    if (!btn) return;
    savedFilterFolder = btn.dataset.savedFilter;
    renderSavedView();
  });

  document.addEventListener('click', e => {
    const openBtn = e.target.closest('[data-open-url]');
    if (openBtn) {
      const url = openBtn.dataset.openUrl;
      if (typeof window.openSavedUrl === 'function') window.openSavedUrl(url);
      return;
    }

    const remBtn = e.target.closest('[data-remove-id]');
    if (remBtn) {
      const id = String(remBtn.dataset.removeId);
      deletedIds.add(id);
      const target = items.find(x => String(x.id) === id);
      if (target) {
        const fObj = folders.find(f => f.name.toLowerCase() === String(target.folder || '').toLowerCase());
        if (fObj && fObj.collab) {
          fObj.deletedIds = Array.isArray(fObj.deletedIds) ? fObj.deletedIds : [];
          if (!fObj.deletedIds.includes(id)) fObj.deletedIds.push(id);
        }
      }
      items = items.filter(x => String(x.id) !== id);
      persistLocal();
      renderAll();
      showToast('Removed.');
      return;
    }

    const folderTile = e.target.closest('[data-open-folder]');
    if (folderTile) {
      activeDetailFolder = folderTile.dataset.openFolder;
      renderFoldersView();
      if (currentUser?.email) syncUserAndCollabWithFirestore(currentUser.email, currentUser.name, false);
    }
  });

  document.getElementById('createOrJoinFolderBtn')?.addEventListener('click', handleCreateOrJoinFolder);
  document.getElementById('newFolderInput')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') handleCreateOrJoinFolder();
  });

  document.getElementById('backToFoldersBtn')?.addEventListener('click', () => {
    activeDetailFolder = '';
    renderFoldersView();
  });

  document.getElementById('toggleCollabBtn')?.addEventListener('click', () => {
    const f = folders.find(x => x.name.toLowerCase() === activeDetailFolder.toLowerCase());
    if (!f) return;
    f.collab = !f.collab;
    if (f.collab) getFolderCollabId(f);
    persistLocal();
    renderAll();
    showToast(f.collab ? `"${f.name}" is now a Collab folder` : `Collab turned off for "${f.name}"`);
  });

  document.getElementById('copyInviteBtn')?.addEventListener('click', () => {
    const f = folders.find(x => x.name.toLowerCase() === activeDetailFolder.toLowerCase());
    if (!f) return;
    f.collab = true;
    const cid = getFolderCollabId(f);
    const joinQuery = `?join=${encodeURIComponent(f.name)}&cid=${encodeURIComponent(cid)}`;
    const inp = document.getElementById('folderQuickInput');
    if (inp) {
      inp.value = joinQuery;
      inp.select();
    }
    persistLocal();
    renderAll();
    showToast('Collab invite code placed in input box to copy!');
  });

  document.getElementById('folderQuickSendBtn')?.addEventListener('click', handleSendInFolder);
  document.getElementById('folderQuickInput')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') handleSendInFolder();
  });

  document.getElementById('userBtn')?.addEventListener('click', async () => {
    document.getElementById('mainView')?.classList.add('hidden');
    document.getElementById('authView')?.classList.remove('hidden');
    await checkPendingGoogleSession();
    if (currentUser?.email) {
      const emailEl = document.getElementById('authEmail');
      if (emailEl && !emailEl.value) emailEl.value = currentUser.email;
    } else if (typeof window.getChromeGoogleAccount === 'function') {
      const chromeAcc = await window.getChromeGoogleAccount();
      const emailEl = document.getElementById('authEmail');
      if (chromeAcc?.email && emailEl && !emailEl.value) {
        emailEl.value = chromeAcc.email;
      }
    }
  });

  document.getElementById('authCancelBtn')?.addEventListener('click', () => {
    document.getElementById('authView')?.classList.add('hidden');
    document.getElementById('mainView')?.classList.remove('hidden');
  });

  document.getElementById('googleBridgeBtn')?.addEventListener('click', handleGoogleAuthClick);
  document.getElementById('authLoginBtn')?.addEventListener('click', handleEmailSyncLogin);

  document.getElementById('signOutBtn')?.addEventListener('click', () => {
    currentUser = null;
    localStorage.removeItem('ll_pending_google_session');
    persistLocal(true);
    renderAll();
    document.getElementById('authView')?.classList.add('hidden');
    document.getElementById('mainView')?.classList.remove('hidden');
    showToast('Signed out.');
  });
});
