// Little Later Chrome Extension — Clipper UI Controller
const STORE_USER = 'll_user_v3';
const STORE_FOLDERS = 'll_folders_v1';
const STORE_ITEMS = 'll_items_v1';

let currentUser = JSON.parse(localStorage.getItem(STORE_USER) || 'null');
let folders = JSON.parse(localStorage.getItem(STORE_FOLDERS) || 'null') || [
  { name: 'Work', kind: 'work', icon: 'work' },
  { name: 'Love', kind: 'love', icon: 'heart' },
  { name: 'Hobby', kind: 'hobby', icon: 'spark' },
  { name: 'Saas video reference', kind: 'folder', icon: 'folder', collab: true }
];
let items = JSON.parse(localStorage.getItem(STORE_ITEMS) || '[]');
const syncChannel = (typeof BroadcastChannel !== 'undefined') ? new BroadcastChannel('ll_collab_sync') : null;

let selectedFolder = folders[0]?.name || 'Work';
let selectedTiming = 'none';

function escapeHtml(val = '') {
  return String(val).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

function showToast(msg) {
  const el = document.getElementById('statusToast');
  if (!el) return;
  el.textContent = msg;
  el.classList.add('visible');
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => el.classList.remove('visible'), 2300);
}

function computeReminderTimestamp(mode) {
  const now = new Date();
  const d = new Date(now);
  if (mode === 'tonight') {
    d.setHours(20, 0, 0, 0);
    if (d.getTime() <= now.getTime()) d.setDate(d.getDate() + 1);
    return d.getTime();
  }
  if (mode === 'tomorrow') {
    d.setDate(d.getDate() + 1);
    d.setHours(19, 0, 0, 0);
    return d.getTime();
  }
  if (mode === 'weekend') {
    const delta = (6 - d.getDay() + 7) % 7 || 7;
    d.setDate(d.getDate() + delta);
    d.setHours(11, 0, 0, 0);
    return d.getTime();
  }
  return 0;
}

function friendlyDate(ts) {
  if (!ts) return 'Unscheduled';
  const date = new Date(ts);
  if (Number.isNaN(date.getTime())) return 'Unscheduled';
  const day = new Intl.DateTimeFormat(undefined, { day: 'numeric', month: 'short' }).format(date);
  const time = new Intl.DateTimeFormat(undefined, { hour: 'numeric', minute: '2-digit' }).format(date);
  return `${day} · ${time}`;
}

function defaultButtonCopy() {
  return 'Save it for later';
}

function persistLocal() {
  localStorage.setItem(STORE_FOLDERS, JSON.stringify(folders));
  localStorage.setItem(STORE_ITEMS, JSON.stringify(items));
  if (currentUser) localStorage.setItem(STORE_USER, JSON.stringify(currentUser));
  else localStorage.removeItem(STORE_USER);
  try {
    syncChannel?.postMessage({ version: Date.now(), folders, items });
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ ll_folders_v1: folders, ll_items_v1: items, ll_user_v3: currentUser });
    }
  } catch (e) {}
}

function renderHeader() {
  const dot = document.getElementById('userDot');
  const label = document.getElementById('userLabel');
  const signedInBox = document.getElementById('signedInBox');
  if (currentUser && currentUser.email) {
    dot?.classList.remove('guest');
    if (label) label.textContent = currentUser.name || currentUser.email.split('@')[0];
    signedInBox?.classList.remove('hidden');
  } else {
    dot?.classList.add('guest');
    if (label) label.textContent = 'Sign in';
    signedInBox?.classList.add('hidden');
  }
}

function renderFolders() {
  const host = document.getElementById('folderChips');
  if (!host) return;
  if (!folders.some(f => f.name === selectedFolder)) {
    selectedFolder = folders[0]?.name || 'Work';
  }
  host.innerHTML = folders.map(f => {
    const isSel = f.name === selectedFolder;
    const iconId = f.kind === 'work' ? '#i-work' : f.kind === 'love' ? '#i-heart' : f.kind === 'hobby' ? '#i-spark' : '#i-folder';
    return `
      <button class="folder-chip ${isSel ? 'selected' : ''}" data-folder="${escapeHtml(f.name)}" type="button">
        <svg><use href="${iconId}"/></svg>
        <span>${escapeHtml(f.name)}</span>
        ${f.collab ? '<span class="collab-dot" title="Shared folder"></span>' : ''}
      </button>`;
  }).join('');
}

function renderSchedulePill() {
  const pill = document.getElementById('scheduleStatePill');
  const btnText = document.getElementById('saveBtnText');
  const ts = computeReminderTimestamp(selectedTiming);
  if (pill) pill.textContent = ts ? friendlyDate(ts) : 'Unscheduled';
  if (btnText) btnText.textContent = defaultButtonCopy();
}

function handleSaveClippedIdea() {
  const btn = document.getElementById('saveIdeaBtn');
  const btnText = document.getElementById('saveBtnText');
  const titleVal = (document.getElementById('tabTitleInput')?.value || '').trim() || 'Saved link';
  const urlVal = (document.getElementById('tabUrlText')?.textContent || '').trim() || 'https://harsh-alt-max.github.io/little-later/';
  const srcVal = (document.getElementById('tabSourcePill')?.textContent || '').trim() || 'Web link';
  const thumbImg = document.querySelector('#tabThumb img')?.getAttribute('src') || '';
  const noteVal = (document.getElementById('noteInput')?.value || '').trim();
  const reminderTs = computeReminderTimestamp(selectedTiming);
  const folderObj = folders.find(f => f.name === selectedFolder) || folders[0];
  const nowTs = Date.now();

  const newItem = {
    id: String(nowTs),
    kind: 'link',
    sender: 'me',
    senderName: currentUser?.name || 'You',
    url: urlVal,
    source: srcVal,
    title: titleVal,
    thumbnail: thumbImg,
    note: noteVal,
    folder: folderObj?.name || 'Work',
    folderKind: folderObj?.kind || 'folder',
    savedAt: nowTs,
    updatedAt: nowTs,
    reminder: reminderTs,
    optedOutBy: []
  };

  items.unshift(newItem);
  persistLocal();

  if (btn) btn.disabled = true;
  if (btnText) btnText.textContent = `Saved to ${newItem.folder} ✓`;
  showToast(`Saved to ${newItem.folder}`);

  setTimeout(() => {
    if (btn) btn.disabled = false;
    if (btnText) btnText.textContent = defaultButtonCopy();
    const noteEl = document.getElementById('noteInput');
    if (noteEl) noteEl.value = '';
  }, 1400);
}

function handleAuthLogin() {
  const email = (document.getElementById('authEmail')?.value || '').trim().toLowerCase();
  const nameInput = (document.getElementById('authPass')?.value || '').trim();
  if (!email || !email.includes('@')) {
    showToast('Enter your email address.');
    return;
  }
  currentUser = {
    name: nameInput || email.split('@')[0],
    email,
    signedInAt: Date.now()
  };
  persistLocal();
  renderHeader();
  renderFolders();
  document.getElementById('authView')?.classList.add('hidden');
  document.getElementById('mainView')?.classList.remove('hidden');
  showToast(`Signed in as ${currentUser.name}`);
}

document.addEventListener('DOMContentLoaded', () => {
  renderHeader();
  renderFolders();
  renderSchedulePill();

  document.getElementById('folderChips')?.addEventListener('click', e => {
    const chip = e.target.closest('[data-folder]');
    if (!chip) return;
    selectedFolder = chip.dataset.folder;
    renderFolders();
  });

  document.getElementById('optionsToggleBtn')?.addEventListener('click', () => {
    const drawer = document.getElementById('optionsDrawer');
    const txt = document.getElementById('optionsToggleText');
    if (!drawer) return;
    const isOpen = drawer.classList.toggle('open');
    if (txt) txt.textContent = isOpen ? 'Hide reminder & note' : 'When should this come back?';
  });

  document.getElementById('timingRow')?.addEventListener('click', e => {
    const pill = e.target.closest('[data-time]');
    if (!pill) return;
    selectedTiming = pill.dataset.time;
    document.querySelectorAll('#timingRow .time-pill').forEach(b => {
      b.classList.toggle('selected', b.dataset.time === selectedTiming);
    });
    renderSchedulePill();
  });

  document.getElementById('saveIdeaBtn')?.addEventListener('click', handleSaveClippedIdea);

  document.getElementById('userBtn')?.addEventListener('click', () => {
    document.getElementById('mainView')?.classList.add('hidden');
    document.getElementById('authView')?.classList.remove('hidden');
  });

  document.getElementById('authCancelBtn')?.addEventListener('click', () => {
    document.getElementById('authView')?.classList.add('hidden');
    document.getElementById('mainView')?.classList.remove('hidden');
  });

  document.getElementById('googleBridgeBtn')?.addEventListener('click', () => {
    const email = (document.getElementById('authEmail')?.value || '').trim().toLowerCase() || 'harshksingh100@gmail.com';
    const nameInput = (document.getElementById('authPass')?.value || '').trim() || 'Harsh';
    currentUser = { name: nameInput, email, provider: 'google', signedInAt: Date.now() };
    persistLocal();
    renderHeader();
    renderFolders();
    document.getElementById('authView')?.classList.add('hidden');
    document.getElementById('mainView')?.classList.remove('hidden');
    showToast(`Signed in as ${currentUser.name}`);
  });

  document.getElementById('authLoginBtn')?.addEventListener('click', handleAuthLogin);

  document.getElementById('signOutBtn')?.addEventListener('click', () => {
    currentUser = null;
    persistLocal();
    renderHeader();
    document.getElementById('authView')?.classList.add('hidden');
    document.getElementById('mainView')?.classList.remove('hidden');
    showToast('Signed out.');
  });
});
