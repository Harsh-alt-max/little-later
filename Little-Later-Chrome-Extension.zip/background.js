// Little Later Chrome Extension — Background Service Worker (Manifest V3)
// Adds Right-Click "Save link to Little Later" context menu & draws the toolbar icon dynamically

function generateToolbarIconImageData(size = 32) {
  if (typeof OffscreenCanvas === 'undefined') return null;
  const canvas = new OffscreenCanvas(size, size);
  const ctx = canvas.getContext('2d');
  const r = Math.round(size * 0.28);

  // Deep blue rounded badge
  ctx.fillStyle = '#28599F';
  ctx.beginPath();
  ctx.moveTo(r, 0);
  ctx.lineTo(size - r, 0);
  ctx.quadraticCurveTo(size, 0, size, r);
  ctx.lineTo(size, size - r);
  ctx.quadraticCurveTo(size, size, size - r, size);
  ctx.lineTo(r, size);
  ctx.quadraticCurveTo(0, size, 0, size - r);
  ctx.lineTo(0, r);
  ctx.quadraticCurveTo(0, 0, r, 0);
  ctx.closePath();
  ctx.fill();

  // Warm gold spark star in center
  ctx.fillStyle = '#F4B936';
  const cx = size / 2;
  const cy = size / 2;
  const outer = size * 0.30;
  const inner = size * 0.13;
  ctx.beginPath();
  for (let i = 0; i < 8; i++) {
    const rad = (i % 2 === 0) ? outer : inner;
    const angle = (i * Math.PI) / 4 - Math.PI / 2;
    const x = cx + Math.cos(angle) * rad;
    const y = cy + Math.sin(angle) * rad;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
  ctx.fill();

  return ctx.getImageData(0, 0, size, size);
}

chrome.runtime.onInstalled.addListener(() => {
  try {
    const img32 = generateToolbarIconImageData(32);
    if (img32) chrome.action.setIcon({ imageData: { 32: img32 } });
  } catch (e) {}

  chrome.contextMenus.create({
    id: 'save-to-little-later',
    title: 'Save to Little Later',
    contexts: ['page', 'link', 'video', 'image']
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'save-to-little-later') {
    chrome.action.openPopup?.();
  }
});
