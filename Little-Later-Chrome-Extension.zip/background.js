// Little Later Chrome Extension — Background Service Worker (Manifest V3)
// Sets the official Little Later mascot toolbar icon and adds the right-click "Save to Little Later" menu

function applyMascotToolbarIcon() {
  try {
    chrome.action.setIcon({
      path: {
        16: 'icons/icon16.png',
        32: 'icons/icon32.png',
        48: 'icons/icon48.png',
        128: 'icons/icon128.png'
      }
    });
  } catch (e) {}
}

chrome.runtime.onInstalled.addListener(() => {
  applyMascotToolbarIcon();
  chrome.contextMenus.create({
    id: 'save-to-little-later',
    title: 'Save to Little Later',
    contexts: ['page', 'link', 'video', 'image']
  });
});

chrome.runtime.onStartup.addListener(() => {
  applyMascotToolbarIcon();
});

chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === 'save-to-little-later') {
    chrome.action.openPopup?.();
  }
});
