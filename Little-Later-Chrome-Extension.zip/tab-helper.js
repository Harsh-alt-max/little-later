// Little Later Chrome Extension — Active Tab Reader (Local UI only)
function detectPlatform(url) {
  try {
    const h = new URL(url).hostname.toLowerCase();
    if (h.includes('instagram')) return 'Instagram';
    if (h.includes('youtube') || h.includes('youtu.be')) return 'YouTube';
    if (h.includes('tiktok')) return 'TikTok';
    if (h.includes('linkedin')) return 'LinkedIn';
    if (h.includes('pinterest') || h.includes('pin.it')) return 'Pinterest';
    if (h.includes('twitter') || h.includes('x.com')) return 'X';
    if (h.includes('github')) return 'GitHub';
    return h.replace(/^www\./, '');
  } catch (e) {
    return 'Web link';
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  const titleEl = document.getElementById('tabTitleInput');
  const urlEl = document.getElementById('tabUrlText');
  const srcEl = document.getElementById('tabSourcePill');
  const thumbEl = document.getElementById('tabThumb');

  if (titleEl && !titleEl.value) titleEl.value = 'Design System & Motion Architecture Breakdown';
  if (urlEl && urlEl.textContent === 'https://…') urlEl.textContent = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ';
  if (srcEl) srcEl.textContent = 'YouTube';

  try {
    if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.query) {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const tab = tabs?.[0];
      if (tab && tab.url && /^https?:\/\//i.test(tab.url)) {
        const cleanTitle = (tab.title || '').replace(/\s*[-|•]\s*(YouTube|Instagram|X|LinkedIn).*$/i, '').trim() || tab.title || 'Saved link';
        if (titleEl) titleEl.value = cleanTitle;
        if (urlEl) urlEl.textContent = tab.url;
        if (srcEl) srcEl.textContent = detectPlatform(tab.url);
        const yt = tab.url.match(/(?:youtube\.com\/(?:shorts\/|watch\?v=)|youtu\.be\/)([A-Za-z0-9_-]{11})/);
        const imgUrl = (yt && yt[1]) ? `https://i.ytimg.com/vi/${yt[1]}/hqdefault.jpg` : (tab.favIconUrl || '');
        if (thumbEl && imgUrl) {
          const img = document.createElement('img');
          img.src = imgUrl;
          img.alt = '';
          thumbEl.innerHTML = '';
          thumbEl.appendChild(img);
        }
      }
    }
  } catch (e) {}
});
