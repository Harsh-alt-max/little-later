# Little Later — Compact Popup Clipper (Chrome Extension)

A fast, one-click Chrome Extension clipper built with the **Deep-Black (`#03050A`) + 11% Blurry Light-Blue Glow** design system that syncs directly with your **Little Later** Android app and collaborative folders.

## Features
- **Auto-Captures Active Tab:** Automatically grabs the current tab's URL, clean title, platform badge (`YouTube`, `Instagram`, `X`, `LinkedIn`, `GitHub`, etc.), and cover thumbnail.
- **Live Cloud & Collaborative Folder Sync:** Sign in with your Little Later account (Email/Password or Google Sign-In) to pull all your phone's folders and drop links straight into personal or shared **Collab** folders in real time.
- **One-Tap Revisit Scheduling:** Pick `None`, `Tonight`, `Tomorrow`, or `Weekend` using the unified rectangular pill system.
- **Right-Click Context Menu:** Right-click any page or link and choose **Save to Little Later**.

## How to Load in Google Chrome (15 Seconds)
1. Open Google Chrome and go to `chrome://extensions/`
2. Toggle **Developer mode** ON (top-right corner).
3. Click **Load unpacked** (top-left button).
4. Select this folder:
   `/Users/harshkumarsingh/Documents/Codex/2026-10-10/i-need-to-create-an-app/outputs/Little-Later-Chrome-Extension`
5. Pin **Little Later** in your Chrome toolbar (puzzle-piece icon → pin) and click it on any tab to save!
